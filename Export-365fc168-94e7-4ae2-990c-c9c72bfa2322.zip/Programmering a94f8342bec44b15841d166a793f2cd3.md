# Programmering

# API

## Databasstruktur

### Användare

```json
{
	"user": "Ivan",
	"password": "Node.js",
	"group": 2,
	"team": 1
}
```

### Sessioner

```jsx

```

### Utmaningar

### Linje 1

### Linje 2

### Linje 3

### Linje 4

# KLIENT

## 1. Logga in

## 2. Lobby 1

## 3. Ledtråd till första stället (Fas 1)

## 4. Lobby 2

- Dela in i grupper

## 5. Dashboard för alla utmaningar (Fas 2)

### Linje 1

### Linje 2

### Linje 3

### Linje 4

## 6. Lobby 2

## 7. Snabba utmaningar

## 8. Outro

# Grafiska element

## Meny

## Inputs

## Meny